import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;

public class Main {
    private static Hotel hotel = new Hotel();

    public static void main(String[] args) {
        JFrame frame = new JFrame();
        frame.setTitle("Lilas' Hotel Reservation");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(690, 420);
        frame.setLayout(null);

        ImageIcon image = new ImageIcon("images.png");
        frame.setIconImage(image.getImage());

        JButton singleButton = new JButton("Single");
        JButton doubleButton = new JButton("Double");
        JButton suiteButton = new JButton("Suite");
        JButton searchButton = new JButton("Search Available Rooms");

        singleButton.setBounds(50, 100, 150, 50);
        doubleButton.setBounds(250, 100, 150, 50);
        suiteButton.setBounds(450, 100, 150, 50);
        searchButton.setBounds(250, 180, 180, 50);

        singleButton.addActionListener(new ActionListener() {
            
            public void actionPerformed(ActionEvent e) {
                showPriceSelector(frame, "Single Room");
            }
        });
        doubleButton.addActionListener(new ActionListener() {
         
            public void actionPerformed(ActionEvent e) {
                showPriceSelector(frame, "Double Room");
            }
        });
        suiteButton.addActionListener(new ActionListener() {
            
            public void actionPerformed(ActionEvent e) {
                showPriceSelector(frame, "Suite Room");
            }
        });

        searchButton.addActionListener(new ActionListener() {
          
            public void actionPerformed(ActionEvent e) {
                showAvailableRooms(frame);
            }
        });

        frame.add(singleButton);
        frame.add(doubleButton);
        frame.add(suiteButton);
        frame.add(searchButton);

        frame.setVisible(true);
    }

    private static void showPriceSelector(JFrame parent, String roomType) {
        JDialog dialog = new JDialog(parent, "Select Price for " + roomType, true);
        dialog.setSize(300, 250);
        dialog.setLayout(null);

        JLabel priceLabel = new JLabel("Selected Price: $50");
        priceLabel.setBounds(90, 20, 200, 20);
        dialog.add(priceLabel);

        JSlider priceSlider = new JSlider(50, 500, 50);
        priceSlider.setBounds(50, 60, 200, 50);
        priceSlider.setPaintTicks(true);
        priceSlider.setPaintLabels(true);
        priceSlider.setMajorTickSpacing(100);
        priceSlider.setMinorTickSpacing(25);

        priceSlider.addChangeListener(e -> {
            int price = priceSlider.getValue();
            priceLabel.setText("Selected Price: $" + price);
        });

        JButton nextButton = new JButton("Next");
        nextButton.setBounds(100, 130, 100, 30);
        nextButton.addActionListener(e -> {
            int selectedPrice = priceSlider.getValue();
            dialog.dispose();
            showNameAndPayment(parent, roomType, selectedPrice);
        });

        dialog.add(priceSlider);
        dialog.add(nextButton);
        dialog.setVisible(true);
    }

    private static void showNameAndPayment(JFrame parent, String roomType, int price) {
        JDialog dialog = new JDialog(parent, "Enter Details for " + roomType, true);
        dialog.setSize(350, 300);
        dialog.setLayout(null);

        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setBounds(50, 30, 100, 20);
        JTextField nameField = new JTextField();
        nameField.setBounds(150, 30, 150, 20);

        JLabel paymentLabel = new JLabel("Payment Type:");
        paymentLabel.setBounds(50, 80, 100, 20);
        JComboBox<String> paymentComboBox = new JComboBox<>(new String[]{"Credit Card", "Cash", "Mobile Payment"});
        paymentComboBox.setBounds(150, 80, 150, 20);

        JButton confirmButton = new JButton("Confirm");
        confirmButton.setBounds(120, 150, 100, 30);
        confirmButton.addActionListener(e -> {
            String name = nameField.getText();
            String paymentType = (String) paymentComboBox.getSelectedItem();

            if (name.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "Please enter your name.", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(parent, "Booking Confirmed!\n" +
                        "Room Type: " + roomType + "\n" +
                        "Price: $" + price + "\n" +
                        "Name: " + name + "\n" +
                        "Payment Type: " + paymentType);
                dialog.dispose();
            }
        });

        dialog.add(nameLabel);
        dialog.add(nameField);
        dialog.add(paymentLabel);
        dialog.add(paymentComboBox);
        dialog.add(confirmButton);
        dialog.setVisible(true);
    }

    private static void showAvailableRooms(JFrame parent) {
        List<Room> availableRooms = hotel.searchAvailableRooms();
        StringBuilder availableRoomsText = new StringBuilder("Available Rooms:\n");

        if (availableRooms.isEmpty()) {
            availableRoomsText.append("No rooms available.");
        } else {
            for (Room room : availableRooms) {
                availableRoomsText.append("Room Number: ").append(room.getRoomNumber())
                        .append(", Type: ").append(room.getType())
                        .append(", Price: $").append(room.getPrice()).append("\n");
            }
        }

        JOptionPane.showMessageDialog(parent, availableRoomsText.toString());
    }

	   /* private static ArrayList<Room> rooms = new ArrayList<>();
	    // List to store reservations
	    private static ArrayList<Reservation> reservations = new ArrayList<>();

	    public static void main(String[] args) {
	        // Initialize some rooms in the hotel
	        initializeRooms();
	        
	        // Create a scanner object for user input
	        Scanner scanner = new Scanner(System.in);
	        
	        // Display menu and prompt user for action
	        System.out.println("Welcome to the Hotel Reservation System");
	        while (true) {
	            System.out.println("\nSelect an option:");
	            System.out.println("1. Search for available rooms");
	            System.out.println("2. Make a reservation");
	            System.out.println("3. View booking details");
	            System.out.println("4. Exit");
	            int choice = scanner.nextInt();
	            
	            switch (choice) {
	                case 1:
	                    searchAvailableRooms();
	                    break;
	                case 2:
	                    makeReservation(scanner);
	                    break;
	                case 3:
	                    viewBookings();
	                    break;
	                case 4:
	                    System.out.println("Thank you for using the Hotel Reservation System!");
	                    scanner.close();
	                    return;
	                default:
	                    System.out.println("Invalid option! Please try again.");
	            }
	        }
	    }

	    // Initialize rooms with default values
	    private static void initializeRooms() {
	        rooms.add(new Room("Single", 101, 100));
	        rooms.add(new Room("Single", 102, 100));
	        rooms.add(new Room("Double", 201, 150));
	        rooms.add(new Room("Double", 202, 150));
	        rooms.add(new Room("Suite", 301, 300));
	    }

	    // Method to search for available rooms
	    private static void searchAvailableRooms() {
	        System.out.println("\nAvailable Rooms:");
	        for (Room room : rooms) {
	            if (room.isAvailable()) {
	                System.out.println("Room " + room.getRoomNumber() + " (" + room.getType() + ") - $" + room.getPrice());
	            }
	        }
	    }

	    // Method to make a reservation
	    private static void makeReservation(Scanner scanner) {
	        System.out.println("\nEnter room type (Single, Double, Suite): ");
	        String roomType = scanner.next();
	        
	        Room availableRoom = findAvailableRoom(roomType);
	        
	        if (availableRoom != null) {
	            System.out.println("Room " + availableRoom.getRoomNumber() + " (" + roomType + ") is available for $" + availableRoom.getPrice());
	            System.out.print("Enter your name: ");
	            String customerName = scanner.next();
	            
	            System.out.println("Select payment method (Credit Card, Cash, Mobile Payment): ");
	            String paymentType = scanner.next();
	            
	            // Create the reservation
	            Reservation reservation = new Reservation(customerName, availableRoom, availableRoom.getPrice(), paymentType);
	            reservations.add(reservation);
	            
	            // Mark room as unavailable
	            availableRoom.bookRoom();
	            
	            System.out.println("\nReservation confirmed!");
	            System.out.println(reservation);
	        } else {
	            System.out.println("Sorry, no available rooms of that type.");
	        }
	    }

	    // Method to view all reservations
	    private static void viewBookings() {
	        System.out.println("\nAll Reservations:");
	        if (reservations.isEmpty()) {
	            System.out.println("No reservations found.");
	        } else {
	            for (Reservation reservation : reservations) {
	                System.out.println(reservation);
	            }
	        }
	    }

	    // Helper method to find an available room by type
	    private static Room findAvailableRoom(String roomType) {
	        for (Room room : rooms) {
	            if (room.getType().equalsIgnoreCase(roomType) && room.isAvailable()) {
	                return room;
	            }
	        }
	        return null; // No available room found
	    }*/
	}


