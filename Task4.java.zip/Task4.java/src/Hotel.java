import java.util.ArrayList;
import java.util.List;

public class Hotel {
    private List<Room> rooms;
    private List<Reservation> reservations;

    public Hotel() {
        rooms = new ArrayList<>();
        reservations = new ArrayList<>();
        
        rooms.add(new Room("Single", 100, 101));
        rooms.add(new Room("Double", 150, 102));
        rooms.add(new Room("Suite", 250, 201));
        rooms.add(new Room("Single", 100, 103));
        rooms.add(new Room("Double", 150, 104));
    }

   
    public Room getAvailableRoom(String type) {
        for (Room room : rooms) {
            if (room.getType().equals(type) && room.isAvailable()) {
                return room;
            }
        }
        return null; 
    }
    
    public List<Room> searchAvailableRooms() {
        List<Room> availableRooms = new ArrayList<>();
        for (Room room : rooms) {
            if (room.isAvailable()) {
                availableRooms.add(room);
            }
        }
        return availableRooms;
    }

    public void makeReservation(String customerName, String roomType, int price, String paymentType) {
        if (isRoomAvailable(roomType)) {
            Reservation reservation = new Reservation(customerName, roomType, price, paymentType);
            reservations.add(reservation);
            Room room = getAvailableRoom(roomType);
            if (room != null) {
                room.bookRoom();
            }
            System.out.println("Reservation successful!");
        } else {
            System.out.println("Sorry, no " + roomType + " room is available.");
        }
    }

    public boolean isRoomAvailable(String type) {
        Room room = getAvailableRoom(type);
        return room != null; 
    }
    
    public List<Reservation> getReservations() {
        return reservations;
    }
}


