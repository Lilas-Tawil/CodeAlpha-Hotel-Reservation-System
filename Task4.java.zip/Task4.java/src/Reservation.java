public class Reservation {
    private String customerName;
    private String roomType;
    private int price;
    private String paymentType;

    public Reservation(String customerName, String roomType, int price, String paymentType) {
        this.customerName = customerName;
        this.roomType = roomType;
        this.price = price;
        this.paymentType = paymentType;
    }

    public String getCustomerName() {
        return customerName;
    }

    public String getRoomType() {
        return roomType;
    }

    public int getPrice() {
        return price;
    }

    public String getPaymentType() {
        return paymentType;
    }

    public String toString() {
        return "Reservation{" +
                "customerName='" + customerName + '\'' +
                ", roomType='" + roomType + '\'' +
                ", price=" + price +
                ", paymentType='" + paymentType + '\'' +
                '}';
    }
}
