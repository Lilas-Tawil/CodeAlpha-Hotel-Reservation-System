public class Room {
    private String type;
    private int price;
    private boolean available;
    private int roomNumber; 

    public Room(String type, int price, int roomNumber) {
        this.type = type;
        this.price = price;
        this.available = true; 
        this.roomNumber = roomNumber;
    }

    public String getType() {
        return type;
    }

    public int getPrice() {
        return price;
    }

    public boolean isAvailable() {
        return available;
    }

    public int getRoomNumber() {
        return roomNumber;
    }

    public void bookRoom() {
        this.available = false; 
    }

    public void cancelRoom() {
        this.available = true; 
    }
}

